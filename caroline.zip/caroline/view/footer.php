<footer>
    <div id="footer_section">
        <div id="contact">
            <a href="###">Nous contacter</a>
        </div>

        <div id="cgu">
            <a href="###">Conditons générales d'utilisation</a>
        </div>

        <div id="inc">
            <p>Copyright Stimulus Inc.</p>
        </div>
    </div>

    <div id="logo">
        <img src="_img/stimulus_logo_small.png" alt ="stimulus_logo" target ="_blank" title = "Stimulus Logo" class="photo"/>
    </div>

</footer>