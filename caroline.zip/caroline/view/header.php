<header>

    <div id="container">

            <div id="logo">
                <a href="###">STIMULUS</a>
            </div>

            <div id="navbar">
                <div id="navbar_menu">
                    <a href="###">
                    <img src="_img/home.png" alt ="home-icon" target ="_blank" title = "Accueil" class="home-icon"/>
                    Accueil</a>

                    <a href="equipe.php">
                    <img src="_img/brain.png" alt ="brain-icon" target ="_blank" title = "Brain" class="brain-icon"/>
                    Qui sommes-nous</a>
    
                    <a href="###">
                    <img src="_img/FAQ.png" alt ="faq-icon" target ="_blank" title = "FAQ" class="faq-icon"/>
                    FAQ</a>
                    <a href="research.php">
                    <img src="_img/research.png" alt ="research-icon" target ="_blank" title = "Research" class="research-icon"/>
                    Rechercher</a>

                    <a href="gestion.php">
                    <img src="_img/gestion.png" alt ="gestion-icon" target ="_blank" title = "Gestion" class="gestion-icon"/>
                    Gestion</a>
                </div>

                <div id="navbar_profil">
                    <a href="###">
                    <img src="_img/profile.png" alt ="profile-icon" target ="_blank" title = "Profile" class="profile-icon"/>
                    Profil</a>
                </div>
            </div>

   
    </div>
</header>